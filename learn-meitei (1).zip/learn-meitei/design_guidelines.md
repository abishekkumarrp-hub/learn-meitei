# Learn Meitei (Manipuri) - Design Guidelines

## Brand Identity

**Purpose**: Educational app helping beginners learn Manipuri language (Meitei Mayek script + English) through structured lessons, alphabet reference, and quizzes. Target users: students in Manipur, diaspora learners, offline-first users.

**Aesthetic Direction**: **Editorial/Educational** - Clean, focused learning environment with typographic hierarchy that emphasizes the beauty of Meitei Mayek script. Approachable, patient, celebratory of cultural heritage.

**Memorable Element**: Large, beautifully rendered Meitei Mayek characters as the hero element on learning cards - making the script itself the star. Warm, encouraging feedback that celebrates every small win.

## Navigation Architecture

**Root Navigation**: Bottom Tab Bar (4 tabs)
- Learn (home/default)
- Alphabet (reference)
- Levels (progress/quiz access)
- Settings (profile/preferences)

**Auth**: None. Local-only storage with simple onboarding asking for user's name.

## Screen-by-Screen Specifications

### 1. Onboarding Screen (First Launch Only)
- **Purpose**: Welcome user, collect name, explain offline nature
- **Layout**: 
  - Centered content (not scrollable)
  - Large welcome illustration at top
  - Heading: "Welcome to Learn Meitei"
  - Text input for name
  - CTA button: "Start Learning"
  - Small text below: "Your progress is saved on this device"
- **No header**
- **Components**: TextInput, Button, illustration, body text

### 2. Learn Tab (Default Landing)
- **Purpose**: Present one Meitei word at a time for focused learning
- **Layout**:
  - Header: Transparent, title "Learn", word counter badge on right (e.g., "1/10")
  - Main content (centered, not scrollable):
    - Large Card containing:
      - Extra large Meitei Mayek word (hero element)
      - Medium roman pronunciation below
      - Body English meaning below that
    - Row of 3 buttons below card: "Listen" (speaker icon), "Next", "Reset"
  - Safe area: top (headerHeight + xl), bottom (tabBarHeight + xl)
- **Empty State**: "Complete! You've reviewed all words. Tap Reset to start again."

### 3. Alphabet Tab
- **Purpose**: Browse and hear pronunciation of Meitei Mayek letters
- **Layout**:
  - Header: Default, title "Alphabet"
  - Segmented control below header: "Iyek Ipee | Chetna Iyek | Lonsum Iyek"
  - Scrollable grid of letter cards (3 columns)
  - Each card: Large Meitei character, small roman pronunciation
  - Tap card to play TTS pronunciation
  - Safe area: top (xl), bottom (tabBarHeight + xl)
- **Components**: ScrollView, Grid, Cards, SegmentedControl

### 4. Levels Tab
- **Purpose**: Show learning progression, access quizzes
- **Layout**:
  - Header: Default, title "Levels"
  - Scrollable list of level cards:
    - Beginner (unlocked, green checkmark if completed)
    - Intermediate (locked, "Coming Soon")
    - Advanced (locked, "Coming Soon")
  - Each unlocked level card shows "Start Quiz" button
  - Progress summary at top: "Words Learned: X | Alphabet Viewed: Y"
  - Safe area: top (xl), bottom (tabBarHeight + xl)
- **Components**: ScrollView, Cards, Progress indicators, Buttons

### 5. Quiz Screen (Modal from Levels)
- **Purpose**: Test knowledge with MCQ quiz
- **Layout**:
  - Header: Custom, title "Beginner Quiz", close button (X) on left
  - Main content (centered):
    - Question number: "Question 1 of 10"
    - Large Meitei word
    - 3 option buttons (full width, stacked)
    - Score indicator at bottom: "Score: X/Y"
  - After answer: Show checkmark/X overlay, brief delay, next question
  - Completion: "Quiz Complete! Score: X/10" with "Done" button
  - Safe area: top (xl), bottom (xl)
- **Navigation**: Native modal over Levels tab

### 6. Settings Tab
- **Purpose**: User info, app settings, data management
- **Layout**:
  - Header: Default, title "Settings"
  - Scrollable form:
    - User name (editable)
    - App version (read-only)
    - "Clear Progress" button (destructive, confirmation alert)
    - Privacy note: "All data stored locally. No internet required."
  - Safe area: top (xl), bottom (tabBarHeight + xl)
- **Components**: ScrollView, TextInput, Buttons, Text

### 7. Review Popup
- **Trigger**: After quiz completion OR 5th session (show once)
- **Layout**: Alert/Modal
  - Title: "Enjoying Learn Meitei?"
  - Message: "Your feedback helps us improve!"
  - Buttons: "Rate App" (primary), "Not Now" (secondary)

## Color Palette

**Primary**: #E67E22 (warm orange - cultural warmth, encouragement)
**Secondary**: #27AE60 (success green for correct answers)
**Background**: #FAFAFA (light warm gray)
**Surface**: #FFFFFF (cards, elevated elements)
**Text Primary**: #2C3E50 (dark blue-gray)
**Text Secondary**: #7F8C8D (muted gray)
**Error/Wrong**: #E74C3C (red)
**Border**: #E0E0E0 (subtle dividers)
**Disabled**: #BDC3C7 (locked levels)

## Typography

**Primary Font**: System Default (San Francisco iOS, Roboto Android) for UI
**Display Font**: Use **Noto Sans** for Meitei Mayek characters (ensure proper Unicode support)

**Type Scale**:
- Hero (Meitei word): 64sp, Bold
- Heading 1: 28sp, Bold
- Heading 2: 22sp, Semibold
- Body Large: 18sp, Regular (pronunciation)
- Body: 16sp, Regular
- Caption: 14sp, Regular (counters, labels)
- Small: 12sp, Regular (hints)

## Visual Design

- **Cards**: Rounded corners (12px), subtle shadow (offset 0,2 opacity 0.08 radius 4), white background
- **Buttons**: Primary (orange bg, white text), Secondary (white bg, orange border), Disabled (gray)
- **Active States**: Reduce opacity to 0.7 on press
- **Icons**: Feather icons from @expo/vector-icons, size 24px for tab bar, 20px inline
- **Spacing**: Use xl (24px) between major sections, lg (16px) between related items, md (12px) within cards
- **Letter Cards**: Minimal padding (16px), centered content, no heavy shadows

## Assets to Generate

1. **icon.png** - App icon featuring stylized Meitei Mayek character in orange on white
   - WHERE USED: Device home screen, app launcher
   
2. **splash-icon.png** - Same icon design for splash screen
   - WHERE USED: App launch screen

3. **welcome-onboarding.png** - Illustration of person reading/learning with Meitei script floating around
   - WHERE USED: Onboarding screen, centered above input

4. **empty-words.png** - Simple illustration of completed checklist with small celebration
   - WHERE USED: Learn tab when all words reviewed

5. **locked-level.png** - Simple padlock icon illustration
   - WHERE USED: Intermediate/Advanced level cards

**Ad Placeholder**: Simple div with text "Ad" and light gray background (#F0F0F0), height 50px, positioned at bottom of Levels and Settings tabs only.