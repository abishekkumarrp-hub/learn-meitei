# Learn Meitei (Manipuri)

## Overview

Learn Meitei (Manipuri) is a mobile-first language learning application designed to help beginners learn the Manipuri language, featuring the Meitei Mayek script alongside English translations. The app provides structured lessons, alphabet reference, and quizzes with a focus on offline capability and local-only data storage.

Target users include students in Manipur, the Manipuri diaspora, and anyone wanting to learn the language offline. The app follows an editorial/educational aesthetic with clean typography that emphasizes the beauty of the Meitei Mayek script.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React Native with Expo SDK 54
- **Navigation**: React Navigation v7 with bottom tab navigation (4 tabs: Learn, Alphabet, Levels, Settings)
- **State Management**: React Query for server state, React Context for ad banner visibility
- **Animations**: React Native Reanimated for smooth UI animations
- **Styling**: StyleSheet-based styling with a centralized theme system (light/dark mode support)

### Directory Structure
- `client/` - React Native/Expo application code
  - `components/` - Reusable UI components (Button, Card, ThemedText, ThemedView)
  - `screens/` - Screen components (Learn, Alphabet, Levels, Settings, Quiz, Onboarding)
  - `navigation/` - Navigation configuration (RootStackNavigator, MainTabNavigator)
  - `data/` - Static data files for words and alphabet
  - `lib/` - Utilities (storage, speech, query-client)
  - `hooks/` - Custom React hooks (useTheme, useScreenOptions)
  - `contexts/` - React Context providers (AdBannerContext)
  - `constants/` - Theme and design tokens
- `server/` - Express.js backend server
- `shared/` - Shared types and schema definitions

### Data Storage
- **Primary Storage**: AsyncStorage for local persistence (user name, progress, word indices, quiz scores)
- **No Authentication**: Local-only experience with simple onboarding that collects user's name
- **Backend Database**: PostgreSQL with Drizzle ORM (schema defined but primarily unused for core app functionality)

### Key Design Decisions

1. **Offline-First Approach**: All learning content and progress stored locally using AsyncStorage, no network dependency for core features
2. **Ad-Ready Architecture**: AdBannerContext and placeholder components prepared for future AdMob integration via Android WebView/PWABuilder
3. **Text-to-Speech Integration**: expo-speech for pronunciation of Meitei words and alphabet letters
4. **Haptic Feedback**: expo-haptics for tactile response on interactions
5. **Cross-Platform**: Supports iOS, Android, and web through Expo's unified platform approach

### Server Architecture
- Express.js server with CORS configuration for Replit domains
- Serves static landing page for web deployment
- API routes prefixed with `/api` (currently minimal usage)
- In-memory storage class with interface for potential database migration

## External Dependencies

### Third-Party Services
- **Expo Services**: Font loading, splash screen, system UI, haptics, speech synthesis
- **No External APIs**: App operates entirely offline for learning functionality

### Key Libraries
- **expo-speech**: Text-to-speech for pronunciation
- **expo-haptics**: Tactile feedback on mobile
- **@react-native-async-storage/async-storage**: Local data persistence
- **@tanstack/react-query**: Data fetching and caching (for potential API integration)
- **drizzle-orm**: Database ORM (prepared for PostgreSQL)

### Database
- PostgreSQL configured via Drizzle ORM
- Schema includes users table with id, username, password fields
- Currently using in-memory storage (MemStorage class) as primary storage